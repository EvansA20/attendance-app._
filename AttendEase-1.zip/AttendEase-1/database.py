import os
from sqlalchemy import create_engine, Column, String, DateTime, Date, Integer, Text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime

DATABASE_URL = os.getenv('DATABASE_URL')

# Initialize database components only if DATABASE_URL is available
engine = None
SessionLocal = None
Base = declarative_base()

def check_database_connection():
    """Check if database is properly configured"""
    return DATABASE_URL is not None

def initialize_database():
    """Initialize database engine and session maker"""
    global engine, SessionLocal
    
    if not DATABASE_URL:
        raise ValueError("DATABASE_URL environment variable is not set. Please configure the PostgreSQL database.")
    
    if engine is None:
        engine = create_engine(DATABASE_URL)
        SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

class Student(Base):
    __tablename__ = 'students'
    
    id = Column(String, primary_key=True)
    name = Column(String, nullable=False)
    email = Column(String, nullable=True)
    phone = Column(String, nullable=True)
    created_date = Column(Date, nullable=False)

class AttendanceRecord(Base):
    __tablename__ = 'attendance_records'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    student_id = Column(String, nullable=False)
    date = Column(Date, nullable=False)
    timestamp = Column(DateTime, nullable=False)
    is_late = Column(String, default='No')

def init_db():
    """Create all tables in the database"""
    initialize_database()
    Base.metadata.create_all(bind=engine)

def get_db():
    """Get database session"""
    db = SessionLocal()
    try:
        return db
    except:
        db.close()
        raise

def add_student(student_id, name, email=None, phone=None, created_date=None):
    """Add a new student to the database"""
    db = SessionLocal()
    try:
        if created_date is None:
            from datetime import date
            created_date = date.today()
        
        student = Student(
            id=student_id,
            name=name,
            email=email,
            phone=phone,
            created_date=created_date
        )
        db.add(student)
        db.commit()
        return True
    except Exception as e:
        db.rollback()
        print(f"Error adding student: {e}")
        return False
    finally:
        db.close()

def get_all_students():
    """Get all students from the database"""
    db = SessionLocal()
    try:
        students = db.query(Student).all()
        return [{
            'id': s.id,
            'name': s.name,
            'email': s.email,
            'phone': s.phone,
            'created_date': s.created_date.isoformat() if s.created_date else None
        } for s in students]
    finally:
        db.close()

def update_student(student_id, name=None, email=None, phone=None):
    """Update an existing student"""
    db = SessionLocal()
    try:
        student = db.query(Student).filter(Student.id == student_id).first()
        if student:
            if name is not None:
                student.name = name
            if email is not None:
                student.email = email
            if phone is not None:
                student.phone = phone
            db.commit()
            return True
        return False
    except Exception as e:
        db.rollback()
        print(f"Error updating student: {e}")
        return False
    finally:
        db.close()

def delete_student(student_id):
    """Delete a student from the database"""
    db = SessionLocal()
    try:
        student = db.query(Student).filter(Student.id == student_id).first()
        if student:
            db.delete(student)
            db.commit()
            return True
        return False
    finally:
        db.close()

def get_student_by_id(student_id):
    """Get a student by ID"""
    db = SessionLocal()
    try:
        student = db.query(Student).filter(Student.id == student_id).first()
        if student:
            return {
                'id': student.id,
                'name': student.name,
                'email': student.email,
                'phone': student.phone,
                'created_date': student.created_date.isoformat() if student.created_date else None
            }
        return None
    finally:
        db.close()

def add_attendance_record(student_id, attendance_date, timestamp=None, is_late='No'):
    """Add an attendance record"""
    db = SessionLocal()
    try:
        if timestamp is None:
            timestamp = datetime.now()
        
        record = AttendanceRecord(
            student_id=student_id,
            date=attendance_date,
            timestamp=timestamp,
            is_late=is_late
        )
        db.add(record)
        db.commit()
        return True
    except Exception as e:
        db.rollback()
        print(f"Error adding attendance record: {e}")
        return False
    finally:
        db.close()

def get_all_attendance_records():
    """Get all attendance records"""
    db = SessionLocal()
    try:
        records = db.query(AttendanceRecord).all()
        return [{
            'id': r.id,
            'student_id': r.student_id,
            'date': r.date.isoformat(),
            'timestamp': r.timestamp.isoformat(),
            'is_late': r.is_late
        } for r in records]
    finally:
        db.close()

def delete_attendance_record(student_id, attendance_date):
    """Delete an attendance record"""
    db = SessionLocal()
    try:
        record = db.query(AttendanceRecord).filter(
            AttendanceRecord.student_id == student_id,
            AttendanceRecord.date == attendance_date
        ).first()
        if record:
            db.delete(record)
            db.commit()
            return True
        return False
    finally:
        db.close()

def check_attendance_exists(student_id, attendance_date):
    """Check if attendance record exists for a student on a date"""
    db = SessionLocal()
    try:
        record = db.query(AttendanceRecord).filter(
            AttendanceRecord.student_id == student_id,
            AttendanceRecord.date == attendance_date
        ).first()
        return record is not None
    finally:
        db.close()
