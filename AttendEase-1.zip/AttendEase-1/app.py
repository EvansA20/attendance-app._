import streamlit as st
import pandas as pd
import qrcode
from io import BytesIO
from PIL import Image
import numpy as np
from datetime import datetime, date
import database as db
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT

# Try to import pyzbar for QR code scanning
try:
    import cv2
    from pyzbar.pyzbar import decode
    PYZBAR_AVAILABLE = True
except ImportError:
    PYZBAR_AVAILABLE = False
    cv2 = None
    decode = None

# Initialize database
try:
    if not db.check_database_connection():
        st.error("⚠️ Database is not configured. Please set the DATABASE_URL environment variable.")
        st.info("The application requires a PostgreSQL database to function. Please contact your administrator to configure the database connection.")
        st.stop()
    
    db.init_db()
except Exception as e:
    st.error(f"⚠️ Database initialization failed: {str(e)}")
    st.info("Please check your database configuration and connection settings.")
    st.stop()

# Load data from database
def load_data():
    st.session_state.students = db.get_all_students()
    st.session_state.attendance_records = db.get_all_attendance_records()

# Initialize session state and load data
if 'students' not in st.session_state:
    load_data()

# Page configuration
st.set_page_config(
    page_title="Student Attendance System",
    page_icon="📚",
    layout="wide"
)

# Title
st.title("📚 Student Attendance Management System")

# Sidebar navigation
st.sidebar.title("Navigation")
page = st.sidebar.radio(
    "Select a page:",
    ["Dashboard", "Student Management", "Mark Attendance", "QR Code Scanner", "QR Code Generator", "Attendance History", "Attendance Trends", "Reports"]
)

# Helper function to generate QR code
def generate_qr_code(student_id, student_name):
    qr_data = f"STUDENT_ID:{student_id}"
    qr = qrcode.QRCode(version=1, box_size=10, border=5)
    qr.add_data(qr_data)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    return img

# Helper function to get student by ID
def get_student_by_id(student_id):
    for student in st.session_state.students:
        if student['id'] == student_id:
            return student
    return None

# Helper function to mark attendance
def mark_attendance(student_id, attendance_date=None, is_late='No'):
    if attendance_date is None:
        attendance_date_str = date.today().isoformat()
        attendance_date_obj = date.today()
    else:
        attendance_date_str = attendance_date if isinstance(attendance_date, str) else attendance_date.isoformat()
        attendance_date_obj = datetime.fromisoformat(attendance_date_str).date() if isinstance(attendance_date, str) else attendance_date
    
    # Check if already marked
    if db.check_attendance_exists(student_id, attendance_date_obj):
        return False, "Already marked present for this date"
    
    # Add attendance record to database
    success = db.add_attendance_record(student_id, attendance_date_obj, datetime.now(), is_late)
    if success:
        load_data()  # Refresh from database
        return True, "Attendance marked successfully"
    return False, "Failed to mark attendance"

# Helper function to generate PDF reports
def generate_pdf_report(report_data, report_title, school_name="School Name"):
    """Generate a PDF report from attendance data"""
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    elements = []
    styles = getSampleStyleSheet()
    
    # Title style
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=24,
        textColor=colors.HexColor('#1f4788'),
        spaceAfter=30,
        alignment=TA_CENTER
    )
    
    # Subtitle style
    subtitle_style = ParagraphStyle(
        'CustomSubtitle',
        parent=styles['Normal'],
        fontSize=12,
        textColor=colors.grey,
        spaceAfter=20,
        alignment=TA_CENTER
    )
    
    # Add school name/branding
    elements.append(Paragraph(school_name, title_style))
    elements.append(Paragraph(report_title, subtitle_style))
    elements.append(Paragraph(f"Generated on: {datetime.now().strftime('%B %d, %Y at %I:%M %p')}", subtitle_style))
    elements.append(Spacer(1, 0.3 * inch))
    
    # Create table data
    table_data = [list(report_data.columns)]  # Header
    for _, row in report_data.iterrows():
        table_data.append(list(row))
    
    # Create table
    table = Table(table_data, repeatRows=1)
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1f4788')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 12),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 1), (-1, -1), 10),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.lightgrey]),
    ]))
    
    elements.append(table)
    
    # Build PDF
    doc.build(elements)
    buffer.seek(0)
    return buffer

# DASHBOARD PAGE
if page == "Dashboard":
    st.header("📊 Dashboard")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Total Students", len(st.session_state.students))
    
    with col2:
        today = date.today().isoformat()
        today_attendance = len([r for r in st.session_state.attendance_records if r['date'] == today])
        st.metric("Present Today", today_attendance)
    
    with col3:
        if len(st.session_state.students) > 0:
            attendance_rate = (today_attendance / len(st.session_state.students)) * 100
            st.metric("Attendance Rate Today", f"{attendance_rate:.1f}%")
        else:
            st.metric("Attendance Rate Today", "N/A")
    
    st.divider()
    
    # Recent activity
    st.subheader("Recent Attendance Records")
    if st.session_state.attendance_records:
        recent_records = sorted(st.session_state.attendance_records, 
                               key=lambda x: x['timestamp'], reverse=True)[:10]
        
        display_data = []
        for record in recent_records:
            student = get_student_by_id(record['student_id'])
            if student:
                display_data.append({
                    'Student Name': student['name'],
                    'Student ID': student['id'],
                    'Date': record['date'],
                    'Time': datetime.fromisoformat(record['timestamp']).strftime('%H:%M:%S')
                })
        
        if display_data:
            st.dataframe(pd.DataFrame(display_data), use_container_width=True)
    else:
        st.info("No attendance records yet")

# STUDENT MANAGEMENT PAGE
elif page == "Student Management":
    st.header("👥 Student Management")
    
    tab1, tab2, tab3 = st.tabs(["Add Student", "View/Edit Students", "Bulk Import/Export"])
    
    with tab1:
        st.subheader("Add New Student")
        
        with st.form("add_student_form"):
            student_name = st.text_input("Student Name*")
            student_id = st.text_input("Student ID*")
            student_email = st.text_input("Email (optional)")
            student_phone = st.text_input("Phone (optional)")
            
            submitted = st.form_submit_button("Add Student")
            
            if submitted:
                if not student_name or not student_id:
                    st.error("Please fill in all required fields (Name and ID)")
                elif any(s['id'] == student_id for s in st.session_state.students):
                    st.error("Student ID already exists!")
                else:
                    success = db.add_student(student_id, student_name, student_email, student_phone, date.today())
                    if success:
                        load_data()
                        st.success(f"Student {student_name} added successfully!")
                        st.rerun()
                    else:
                        st.error("Failed to add student. Please try again.")
    
    with tab2:
        st.subheader("Student List")
        
        if st.session_state.students:
            for idx, student in enumerate(st.session_state.students):
                with st.expander(f"{student['name']} - ID: {student['id']}"):
                    # Check if in edit mode for this student
                    edit_key = f"edit_mode_{idx}"
                    if edit_key not in st.session_state:
                        st.session_state[edit_key] = False
                    
                    if st.session_state[edit_key]:
                        # Edit mode
                        with st.form(key=f"edit_form_{idx}"):
                            edit_name = st.text_input("Student Name*", value=student['name'])
                            edit_id = st.text_input("Student ID*", value=student['id'], disabled=True, help="Student ID cannot be changed")
                            edit_email = st.text_input("Email (optional)", value=student.get('email', ''))
                            edit_phone = st.text_input("Phone (optional)", value=student.get('phone', ''))
                            
                            col1, col2 = st.columns(2)
                            with col1:
                                save_btn = st.form_submit_button("Save Changes")
                            with col2:
                                cancel_btn = st.form_submit_button("Cancel")
                            
                            if save_btn:
                                if not edit_name:
                                    st.error("Student name is required!")
                                else:
                                    success = db.update_student(student['id'], edit_name, edit_email, edit_phone)
                                    if success:
                                        load_data()
                                        st.session_state[edit_key] = False
                                        st.success("Student updated successfully!")
                                        st.rerun()
                                    else:
                                        st.error("Failed to update student.")
                            
                            if cancel_btn:
                                st.session_state[edit_key] = False
                                st.rerun()
                    else:
                        # View mode
                        col1, col2 = st.columns([3, 1])
                        
                        with col1:
                            st.write(f"**Name:** {student['name']}")
                            st.write(f"**ID:** {student['id']}")
                            if student.get('email'):
                                st.write(f"**Email:** {student['email']}")
                            if student.get('phone'):
                                st.write(f"**Phone:** {student['phone']}")
                        
                        with col2:
                            if st.button("Edit", key=f"edit_{idx}"):
                                st.session_state[edit_key] = True
                                st.rerun()
                            
                            if st.button("Delete", key=f"delete_{idx}"):
                                success = db.delete_student(student['id'])
                                if success:
                                    load_data()
                                    st.success("Student deleted!")
                                    st.rerun()
                                else:
                                    st.error("Failed to delete student.")
        else:
            st.info("No students added yet. Add your first student in the 'Add Student' tab.")
    
    with tab3:
        st.subheader("Bulk Import/Export")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("### Export Student Roster")
            st.write("Download all students as a CSV file")
            
            if st.session_state.students:
                export_df = pd.DataFrame(st.session_state.students)
                csv_export = export_df.to_csv(index=False)
                
                st.download_button(
                    label="Download Student Roster (CSV)",
                    data=csv_export,
                    file_name=f"student_roster_{date.today().isoformat()}.csv",
                    mime="text/csv"
                )
                
                st.caption(f"Total students to export: {len(st.session_state.students)}")
            else:
                st.info("No students to export")
        
        with col2:
            st.markdown("### Import Student Roster")
            st.write("Upload a CSV file with student data")
            
            st.caption("CSV should have columns: id, name, email (optional), phone (optional)")
            
            uploaded_csv = st.file_uploader("Upload CSV File", type=['csv'], key="bulk_import")
            
            if uploaded_csv is not None:
                try:
                    import_df = pd.read_csv(uploaded_csv)
                    
                    # Validate required columns
                    if 'id' not in import_df.columns or 'name' not in import_df.columns:
                        st.error("CSV must contain 'id' and 'name' columns")
                    else:
                        st.write("Preview:")
                        st.dataframe(import_df.head(), use_container_width=True)
                        
                        if st.button("Import Students"):
                            success_count = 0
                            error_count = 0
                            
                            for _, row in import_df.iterrows():
                                student_id = str(row['id'])
                                student_name = str(row['name'])
                                student_email = str(row.get('email', '')) if pd.notna(row.get('email')) else ''
                                student_phone = str(row.get('phone', '')) if pd.notna(row.get('phone')) else ''
                                
                                # Check if student already exists
                                if not any(s['id'] == student_id for s in st.session_state.students):
                                    success = db.add_student(student_id, student_name, student_email, student_phone, date.today())
                                    if success:
                                        success_count += 1
                                    else:
                                        error_count += 1
                                else:
                                    error_count += 1
                            
                            load_data()
                            
                            if success_count > 0:
                                st.success(f"Successfully imported {success_count} students")
                            if error_count > 0:
                                st.warning(f"{error_count} students skipped (duplicates or errors)")
                            
                            st.rerun()
                
                except Exception as e:
                    st.error(f"Error reading CSV file: {str(e)}")

# MARK ATTENDANCE PAGE
elif page == "Mark Attendance":
    st.header("✅ Mark Attendance (Manual Entry)")
    
    if not st.session_state.students:
        st.warning("No students registered. Please add students first.")
    else:
        col1, col2 = st.columns([2, 1])
        
        with col1:
            selected_date = st.date_input("Select Date", value=date.today())
            selected_date_str = selected_date.isoformat()
        
        with col2:
            # Late arrival cutoff time
            cutoff_time = st.time_input("Late Arrival Cutoff Time", value=datetime.strptime("09:00", "%H:%M").time())
        
        st.divider()
        st.subheader(f"Mark Attendance for {selected_date.strftime('%B %d, %Y')}")
        st.caption(f"Students arriving after {cutoff_time.strftime('%I:%M %p')} will be marked as late")
        
        # Show all students with checkboxes
        for student in st.session_state.students:
            # Check if already marked
            existing_record = next(
                (r for r in st.session_state.attendance_records 
                 if r['student_id'] == student['id'] and r['date'] == selected_date_str),
                None
            )
            
            col1, col2, col3 = st.columns([3, 1, 1])
            
            with col1:
                st.write(f"**{student['name']}** (ID: {student['id']})")
            
            with col2:
                if existing_record:
                    if existing_record.get('is_late', 'No') == 'Yes':
                        st.warning("⏰ Late")
                    else:
                        st.success("✓ On Time")
            
            with col3:
                if not existing_record:
                    if st.button("Mark Present", key=f"mark_{student['id']}"):
                        # Determine if late based on current time
                        current_time = datetime.now().time()
                        is_late = 'Yes' if current_time > cutoff_time else 'No'
                        
                        success, message = mark_attendance(student['id'], selected_date_str, is_late)
                        if success:
                            st.success(message)
                            st.rerun()
                        else:
                            st.error(message)
                else:
                    if st.button("Unmark", key=f"unmark_{student['id']}"):
                        success = db.delete_attendance_record(student['id'], selected_date)
                        if success:
                            load_data()
                            st.success("Attendance unmarked")
                            st.rerun()
                        else:
                            st.error("Failed to unmark attendance.")

# QR CODE SCANNER PAGE
elif page == "QR Code Scanner":
    st.header("📷 QR Code Scanner")
    
    if not PYZBAR_AVAILABLE:
        st.warning("⚠️ QR code scanning library is not available. Please use the manual attendance marking feature instead.")
        st.info("You can still generate QR codes in the 'QR Code Generator' page for future use.")
    else:
        st.info("Upload a QR code image or use your camera to scan student QR codes for quick attendance marking.")
        
        # Late arrival cutoff time configuration
        cutoff_time = st.time_input("Late Arrival Cutoff Time", value=datetime.strptime("09:00", "%H:%M").time(), key="qr_cutoff_time")
        st.caption(f"Students checking in after {cutoff_time.strftime('%I:%M %p')} will be marked as late")
        
        scan_method = st.radio("Select scanning method:", ["Upload Image", "Camera Capture"])
        
        if scan_method == "Upload Image":
            uploaded_file = st.file_uploader("Upload QR Code Image", type=['png', 'jpg', 'jpeg'])
            
            if uploaded_file is not None:
                # Read image
                file_bytes = np.asarray(bytearray(uploaded_file.read()), dtype=np.uint8)
                image = cv2.imdecode(file_bytes, cv2.IMREAD_COLOR)
                
                # Display image
                st.image(image, channels="BGR", caption="Uploaded Image")
                
                # Decode QR code
                decoded_objects = decode(image)
                
                if decoded_objects:
                    for obj in decoded_objects:
                        qr_data = obj.data.decode('utf-8')
                        st.success(f"QR Code detected: {qr_data}")
                        
                        # Extract student ID
                        if qr_data.startswith("STUDENT_ID:"):
                            student_id = qr_data.replace("STUDENT_ID:", "")
                            student = get_student_by_id(student_id)
                            
                            if student:
                                st.write(f"**Student:** {student['name']}")
                                st.write(f"**ID:** {student['id']}")
                                
                                if st.button("Mark Attendance Now"):
                                    # Determine if late based on current time
                                    current_time = datetime.now().time()
                                    is_late = 'Yes' if current_time > cutoff_time else 'No'
                                    
                                    success, message = mark_attendance(student_id, datetime.now().date().isoformat(), is_late)
                                    if success:
                                        st.success(f"✅ {message} for {student['name']}")
                                    else:
                                        st.warning(message)
                            else:
                                st.error("Student not found in the system!")
                else:
                    st.warning("No QR code detected in the image. Please upload a clear QR code image.")
        
        else:  # Camera Capture
            st.info("Camera capture feature: Take a photo of the QR code using the camera input below.")
            
            camera_image = st.camera_input("Capture QR Code")
            
            if camera_image is not None:
                # Read image
                file_bytes = np.asarray(bytearray(camera_image.read()), dtype=np.uint8)
                image = cv2.imdecode(file_bytes, cv2.IMREAD_COLOR)
                
                # Decode QR code
                decoded_objects = decode(image)
                
                if decoded_objects:
                    for obj in decoded_objects:
                        qr_data = obj.data.decode('utf-8')
                        st.success(f"QR Code detected: {qr_data}")
                        
                        # Extract student ID
                        if qr_data.startswith("STUDENT_ID:"):
                            student_id = qr_data.replace("STUDENT_ID:", "")
                            student = get_student_by_id(student_id)
                            
                            if student:
                                st.write(f"**Student:** {student['name']}")
                                st.write(f"**ID:** {student['id']}")
                                
                                if st.button("Mark Attendance Now"):
                                    # Determine if late based on current time
                                    current_time = datetime.now().time()
                                    is_late = 'Yes' if current_time > cutoff_time else 'No'
                                    
                                    success, message = mark_attendance(student_id, datetime.now().date().isoformat(), is_late)
                                    if success:
                                        st.success(f"✅ {message} for {student['name']}")
                                        st.rerun()
                                    else:
                                        st.warning(message)
                            else:
                                st.error("Student not found in the system!")
                else:
                    st.warning("No QR code detected. Please capture a clear image of the QR code.")

# QR CODE GENERATOR PAGE
elif page == "QR Code Generator":
    st.header("🔲 QR Code Generator")
    
    if not st.session_state.students:
        st.warning("No students registered. Please add students first.")
    else:
        st.info("Generate QR codes for students to enable quick attendance scanning.")
        
        # Option to generate for all or individual
        generation_type = st.radio("Generate QR codes for:", ["Individual Student", "All Students"])
        
        if generation_type == "Individual Student":
            student_names = [f"{s['name']} (ID: {s['id']})" for s in st.session_state.students]
            selected_student = st.selectbox("Select Student", student_names)
            
            if selected_student:
                # Extract student ID
                student_id = selected_student.split("ID: ")[1].rstrip(")")
                student = get_student_by_id(student_id)
                
                if student:
                    # Generate QR code
                    qr_img = generate_qr_code(student['id'], student['name'])
                    
                    # Display QR code
                    col1, col2 = st.columns([1, 2])
                    
                    with col1:
                        st.image(qr_img, caption=f"QR Code for {student['name']}")
                        
                        # Download button
                        buf = BytesIO()
                        qr_img.save(buf, format="PNG")
                        buf.seek(0)
                        
                        st.download_button(
                            label="Download QR Code",
                            data=buf,
                            file_name=f"qr_{student['id']}.png",
                            mime="image/png"
                        )
                    
                    with col2:
                        st.write(f"**Student Name:** {student['name']}")
                        st.write(f"**Student ID:** {student['id']}")
                        st.write("Print this QR code and give it to the student. They can use it for quick attendance check-in.")
        
        else:  # All Students
            st.subheader("QR Codes for All Students")
            
            cols = st.columns(3)
            
            for idx, student in enumerate(st.session_state.students):
                with cols[idx % 3]:
                    qr_img = generate_qr_code(student['id'], student['name'])
                    st.image(qr_img, caption=f"{student['name']} ({student['id']})", use_container_width=True)
                    
                    # Download button
                    buf = BytesIO()
                    qr_img.save(buf, format="PNG")
                    buf.seek(0)
                    
                    st.download_button(
                        label=f"Download",
                        data=buf,
                        file_name=f"qr_{student['id']}.png",
                        mime="image/png",
                        key=f"download_{student['id']}"
                    )

# ATTENDANCE HISTORY PAGE
elif page == "Attendance History":
    st.header("📅 Attendance History")
    
    if not st.session_state.attendance_records:
        st.info("No attendance records yet.")
    else:
        # Filters
        col1, col2 = st.columns(2)
        
        with col1:
            # Date range filter
            all_dates = sorted(list(set([r['date'] for r in st.session_state.attendance_records])))
            
            if all_dates:
                start_date = st.date_input("From Date", value=datetime.fromisoformat(all_dates[0]).date())
                
        with col2:
            if all_dates:
                end_date = st.date_input("To Date", value=datetime.fromisoformat(all_dates[-1]).date())
        
        # Student filter
        student_filter = st.multiselect(
            "Filter by Student",
            options=[s['name'] for s in st.session_state.students],
            default=[]
        )
        
        # Filter records
        filtered_records = st.session_state.attendance_records
        
        if all_dates:
            filtered_records = [
                r for r in filtered_records 
                if start_date.isoformat() <= r['date'] <= end_date.isoformat()
            ]
        
        if student_filter:
            student_ids = [s['id'] for s in st.session_state.students if s['name'] in student_filter]
            filtered_records = [r for r in filtered_records if r['student_id'] in student_ids]
        
        # Display records
        if filtered_records:
            display_data = []
            for record in sorted(filtered_records, key=lambda x: (x['date'], x['timestamp']), reverse=True):
                student = get_student_by_id(record['student_id'])
                if student:
                    display_data.append({
                        'Date': record['date'],
                        'Student Name': student['name'],
                        'Student ID': student['id'],
                        'Check-in Time': datetime.fromisoformat(record['timestamp']).strftime('%H:%M:%S'),
                        'Status': '⏰ Late' if record.get('is_late', 'No') == 'Yes' else '✓ On Time'
                    })
            
            st.dataframe(pd.DataFrame(display_data), use_container_width=True)
            
            # Statistics
            st.divider()
            st.subheader("Statistics")
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("Total Records", len(filtered_records))
            
            with col2:
                unique_dates = len(set([r['date'] for r in filtered_records]))
                st.metric("Days Covered", unique_dates)
            
            with col3:
                unique_students = len(set([r['student_id'] for r in filtered_records]))
                st.metric("Unique Students", unique_students)
        else:
            st.info("No records found for the selected filters.")

# ATTENDANCE TRENDS PAGE
elif page == "Attendance Trends":
    st.header("📈 Attendance Trends & Visualization")
    
    if not st.session_state.attendance_records or not st.session_state.students:
        st.info("Add students and attendance records to view trends.")
    else:
        # Get date range from records
        all_dates = sorted(list(set([r['date'] for r in st.session_state.attendance_records])))
        
        if not all_dates:
            st.info("No attendance data available yet.")
        else:
            st.subheader("Daily Attendance Trend")
            
            # Create daily attendance data
            daily_data = {}
            for record_date in all_dates:
                count = len([r for r in st.session_state.attendance_records if r['date'] == record_date])
                daily_data[record_date] = count
            
            # Create DataFrame for charting
            trend_df = pd.DataFrame({
                'Date': list(daily_data.keys()),
                'Students Present': list(daily_data.values())
            })
            trend_df['Date'] = pd.to_datetime(trend_df['Date'])
            trend_df = trend_df.sort_values('Date')
            
            # Display line chart
            st.line_chart(trend_df.set_index('Date'))
            
            st.divider()
            
            # Individual student trends
            st.subheader("Individual Student Attendance")
            
            selected_student = st.selectbox(
                "Select Student",
                options=[s['name'] for s in st.session_state.students]
            )
            
            if selected_student:
                student = next((s for s in st.session_state.students if s['name'] == selected_student), None)
                
                if student:
                    student_records = [r for r in st.session_state.attendance_records if r['student_id'] == student['id']]
                    
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        st.metric("Days Present", len(student_records))
                    
                    with col2:
                        total_days = len(all_dates)
                        st.metric("Total School Days", total_days)
                    
                    with col3:
                        if total_days > 0:
                            attendance_pct = (len(student_records) / total_days) * 100
                            st.metric("Attendance Rate", f"{attendance_pct:.1f}%")
                    
                    st.divider()
                    
                    # Weekly/Monthly breakdown
                    st.subheader("Attendance Pattern")
                    
                    if len(student_records) > 0:
                        # Create presence data for bar chart
                        student_dates = [r['date'] for r in student_records]
                        
                        # Group by week
                        date_df = pd.DataFrame({'Date': student_dates})
                        date_df['Date'] = pd.to_datetime(date_df['Date'])
                        date_df['Week'] = date_df['Date'].dt.strftime('%Y-W%U')
                        
                        weekly_counts = date_df.groupby('Week').size().reset_index(name='Days Present')
                        
                        st.bar_chart(weekly_counts.set_index('Week'))
                        
                        st.caption("Bar chart showing attendance by week")
                    else:
                        st.info(f"No attendance records for {selected_student} yet.")
            
            st.divider()
            
            # Overall class statistics
            st.subheader("Class Attendance Statistics")
            
            if len(all_dates) > 0:
                # Calculate average daily attendance
                total_students = len(st.session_state.students)
                avg_daily_attendance = sum(daily_data.values()) / len(daily_data)
                avg_attendance_rate = (avg_daily_attendance / total_students * 100) if total_students > 0 else 0
                
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.metric("Average Daily Attendance", f"{avg_daily_attendance:.1f}")
                
                with col2:
                    st.metric("Average Attendance Rate", f"{avg_attendance_rate:.1f}%")
                
                with col3:
                    st.metric("Total Days Tracked", len(all_dates))
                
                # Top and bottom performers
                st.divider()
                st.subheader("Student Performance Overview")
                
                student_stats = []
                for student in st.session_state.students:
                    student_count = len([r for r in st.session_state.attendance_records if r['student_id'] == student['id']])
                    pct = (student_count / len(all_dates) * 100) if len(all_dates) > 0 else 0
                    student_stats.append({
                        'Student Name': student['name'],
                        'Days Present': student_count,
                        'Attendance %': f"{pct:.1f}%"
                    })
                
                stats_df = pd.DataFrame(student_stats)
                stats_df = stats_df.sort_values('Days Present', ascending=False)
                
                st.dataframe(stats_df, use_container_width=True)

# REPORTS PAGE
elif page == "Reports":
    st.header("📊 Reports & Analytics")
    
    if not st.session_state.attendance_records or not st.session_state.students:
        st.info("Add students and attendance records to generate reports.")
    else:
        # Report type selection
        report_type = st.selectbox(
            "Select Report Type",
            ["Daily Attendance Report", "Student Attendance Summary", "Date Range Report"]
        )
        
        if report_type == "Daily Attendance Report":
            selected_date = st.date_input("Select Date", value=date.today())
            selected_date_str = selected_date.isoformat()
            
            # Get attendance for the date
            day_records = [r for r in st.session_state.attendance_records if r['date'] == selected_date_str]
            
            report_data = []
            for student in st.session_state.students:
                is_present = any(r['student_id'] == student['id'] for r in day_records)
                record = next((r for r in day_records if r['student_id'] == student['id']), None)
                
                report_data.append({
                    'Student Name': student['name'],
                    'Student ID': student['id'],
                    'Status': 'Present' if is_present else 'Absent',
                    'Check-in Time': datetime.fromisoformat(record['timestamp']).strftime('%H:%M:%S') if record else 'N/A'
                })
            
            df = pd.DataFrame(report_data)
            st.dataframe(df, use_container_width=True)
            
            # Summary
            present_count = len([r for r in report_data if r['Status'] == 'Present'])
            absent_count = len(report_data) - present_count
            
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Total Students", len(report_data))
            with col2:
                st.metric("Present", present_count)
            with col3:
                st.metric("Absent", absent_count)
            
            # Download options
            col1, col2 = st.columns(2)
            
            with col1:
                csv = df.to_csv(index=False)
                st.download_button(
                    label="Download Report as CSV",
                    data=csv,
                    file_name=f"attendance_report_{selected_date_str}.csv",
                    mime="text/csv"
                )
            
            with col2:
                school_name = st.text_input("School Name (for PDF)", value="Student Attendance System", key="school_name_daily")
                pdf_buffer = generate_pdf_report(df, f"Daily Attendance Report - {selected_date.strftime('%B %d, %Y')}", school_name)
                st.download_button(
                    label="Download Report as PDF",
                    data=pdf_buffer,
                    file_name=f"attendance_report_{selected_date_str}.pdf",
                    mime="application/pdf"
                )
        
        elif report_type == "Student Attendance Summary":
            # Calculate attendance percentage for each student
            summary_data = []
            
            for student in st.session_state.students:
                student_records = [r for r in st.session_state.attendance_records if r['student_id'] == student['id']]
                
                # Get all unique dates in attendance records
                all_dates = set([r['date'] for r in st.session_state.attendance_records])
                
                days_present = len(student_records)
                total_days = len(all_dates) if all_dates else 0
                
                attendance_percentage = (days_present / total_days * 100) if total_days > 0 else 0
                
                summary_data.append({
                    'Student Name': student['name'],
                    'Student ID': student['id'],
                    'Days Present': days_present,
                    'Total Days': total_days,
                    'Attendance %': f"{attendance_percentage:.1f}%"
                })
            
            df = pd.DataFrame(summary_data)
            st.dataframe(df, use_container_width=True)
            
            # Download options
            col1, col2 = st.columns(2)
            
            with col1:
                csv = df.to_csv(index=False)
                st.download_button(
                    label="Download Summary as CSV",
                    data=csv,
                    file_name="student_attendance_summary.csv",
                    mime="text/csv"
                )
            
            with col2:
                school_name = st.text_input("School Name (for PDF)", value="Student Attendance System", key="school_name_summary")
                pdf_buffer = generate_pdf_report(df, "Student Attendance Summary", school_name)
                st.download_button(
                    label="Download Summary as PDF",
                    data=pdf_buffer,
                    file_name="student_attendance_summary.pdf",
                    mime="application/pdf"
                )
        
        else:  # Date Range Report
            col1, col2 = st.columns(2)
            
            all_dates = sorted(list(set([r['date'] for r in st.session_state.attendance_records])))
            
            if all_dates:
                with col1:
                    start_date = st.date_input("From Date", value=datetime.fromisoformat(all_dates[0]).date())
                
                with col2:
                    end_date = st.date_input("To Date", value=datetime.fromisoformat(all_dates[-1]).date())
                
                # Filter records by date range
                range_records = [
                    r for r in st.session_state.attendance_records 
                    if start_date.isoformat() <= r['date'] <= end_date.isoformat()
                ]
                
                if range_records:
                    # Create detailed report
                    report_data = []
                    for record in sorted(range_records, key=lambda x: (x['date'], x['timestamp'])):
                        student = get_student_by_id(record['student_id'])
                        if student:
                            report_data.append({
                                'Date': record['date'],
                                'Student Name': student['name'],
                                'Student ID': student['id'],
                                'Check-in Time': datetime.fromisoformat(record['timestamp']).strftime('%H:%M:%S')
                            })
                    
                    df = pd.DataFrame(report_data)
                    st.dataframe(df, use_container_width=True)
                    
                    # Summary statistics
                    st.divider()
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        st.metric("Total Records", len(range_records))
                    with col2:
                        unique_dates = len(set([r['date'] for r in range_records]))
                        st.metric("Days Covered", unique_dates)
                    with col3:
                        unique_students = len(set([r['student_id'] for r in range_records]))
                        st.metric("Students Attended", unique_students)
                    
                    # Download options
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        csv = df.to_csv(index=False)
                        st.download_button(
                            label="Download Report as CSV",
                            data=csv,
                            file_name=f"attendance_report_{start_date}_{end_date}.csv",
                            mime="text/csv"
                        )
                    
                    with col2:
                        school_name = st.text_input("School Name (for PDF)", value="Student Attendance System", key="school_name_range")
                        pdf_buffer = generate_pdf_report(df, f"Attendance Report ({start_date} to {end_date})", school_name)
                        st.download_button(
                            label="Download Report as PDF",
                            data=pdf_buffer,
                            file_name=f"attendance_report_{start_date}_{end_date}.pdf",
                            mime="application/pdf"
                        )
                else:
                    st.info("No records found in the selected date range.")
            else:
                st.info("No attendance records available yet.")

# Footer
st.divider()
st.caption("Student Attendance Management System - Built with Streamlit")
